<?php
//Activity 1
//Emily Quevedo
//January 7, 2021
//This is my own work

/*Handles user business logic and connections to database*/
namespace App\Http\Services\Business;

use \mysqli;
use \PDO;
use App\Models\RecipeModel;
use App\Http\Services\Data\RecipeDataService;

class RecipeBusinessService {
/**
     * Create Recipe
     * @param RecipeModel $recipe
     * @return boolean
     */
    public function create(RecipeModel $recipe) {
        $servername = config("database.connections.mysql.host");
        $dbname = config("database.connections.mysql.database");
        $username = config("database.connections.mysql.username");
        $password = config("database.connections.mysql.password");

        $conn = new mysqli($servername, $username, $password, $dbname);

        //create a recipe service dao with this connection and try to create recipe
        $service = new RecipeDataService($conn);
        $flag = $service->createRecipe($recipe);

        //return the finder results
        return $flag;
    }

    public function findAll() {
        $servername = config("database.connections.mysql.host");
        $dbname = config("database.connections.mysql.database");
        $username = config("database.connections.mysql.username");
        $password = config("database.connections.mysql.password");

        $conn = new mysqli($servername, $username, $password, $dbname);

        //create a recipe service dao with this connection and try to find all recipes in database
        $service = new RecipeDataService($conn);
        $flag = $service->readAllRecipes();

        //return the finder results
        return $flag;
    }
}

?>
