<?php $__env->startSection('title', 'Add Recipe'); ?>

<?php $__env->startSection('content'); ?>
    <div class="recipe-form">
        <form action="addRecipe" method="POST">
            <h2 class="text-center">Add A Recipe</h2>
            <input type="hidden" name="_token" value = "<?php echo csrf_token()?>">
            <div class="form-group">
                <label>Recipe Title:</label>
                <input type="text" class="form-control" name="title" placeholder="" required="required">
            </div>
            <div class="form-group">
                <label>Description:</label>
                <textarea class="form-control" name="description" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label>Ingredients:</label>
                <textarea class="form-control" name="ingredients" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label>Directions:</label>
                <textarea class="form-control" name="directions" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label>Estimated Time:</label>
                <input type="text" class="form-control" name="time" placeholder="Ex: 30 mins" required="required">
            </div>
            <div class="form-group">
                <label>Add Image:</label><br>
                <input type="file" id="myFile" name="image">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block">Submit</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RecipeApp\resources\views/addRecipe.blade.php ENDPATH**/ ?>