<nav class="navbar navbar-expand-lg navbar-light">
    <a href="#" class="navbar-brand">Emily's<b>Cook</b>Book</a>
    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- Collection of nav links, forms, and other content for toggling -->
    <div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
        <div class="navbar-nav">
            <a href="/home" class="nav-item nav-link">Home</a>
            <a href="/addRecipe" class="nav-item nav-link">Add A Recipe</a>
            <a href="/allRecipes" class="nav-item nav-link">All Recipes</a>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\RecipeApp\resources\views/layouts/header.blade.php ENDPATH**/ ?>