<?php $__env->startSection('title', 'Home'); ?>

<?php
use App\Http\Services\Business\RecipeBusinessService;

//user business service is called
$bs = new RecipeBusinessService();
$recipes = $bs->findAll();
?>

<?php $__env->startSection('content'); ?>
    <div class="container">
      <h3>Emily's Personal Cook Book</h3>
    </div>


    <div class="container">
        <div class="row">
            <?php
    for ($x = 0; $x < count($recipes); $x++) { ?>
            <div class="col-md-4">
                <div class="card-content">
                    <div class="card-img">
                        <img src="/images/<?php echo e($recipes[$x]['image']); ?>" alt="">
                    </div>
                    <div class="card-desc">
                        <h3><?php echo e($recipes[$x]['title']); ?></h3>
                        <p><small>Estimated Time: <?php echo e($recipes[$x]['time']); ?></small></p>
                        <p><?php echo e($recipes[$x]['description']); ?></p>
                            <a href="#" class="btn-card">See Recipe</a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RecipeApp\resources\views/home.blade.php ENDPATH**/ ?>