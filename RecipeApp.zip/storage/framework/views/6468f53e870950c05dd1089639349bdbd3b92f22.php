<h1>TEST</h1>
<?php /**PATH C:\xampp\htdocs\RecipeApp\resources\views/test.blade.php ENDPATH**/ ?>