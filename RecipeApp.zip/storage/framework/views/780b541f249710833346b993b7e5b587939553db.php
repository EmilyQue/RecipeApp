<h1>SUCCESS</h1>
<?php /**PATH C:\xampp\htdocs\RecipeApp\resources\views/registerSuccess.blade.php ENDPATH**/ ?>